# @local/session-title-control

会话标题的两个增强：

1. **失败自动重试**：替换内置的首问标题 provider；单次模型调用失败时最多重试 5 次（指数退避 + 抖动），每次尝试仍有独立的超时上限。
2. **手动重排标题**：按当前会话内容（全部人类提问 + 最近一条助手回复的摘要）重新生成标题。入口有两个：
   - 会话头部的「重排标题」按钮（slot `conversation.session.header.actions`）
   - 输入框命令 `/retitle`（立即返回，后台生成）

标题仍由 `@deepseek-ai/dsh-session-title` 写入 `session/title` 事件，侧栏通过正常投影更新，不会进入模型上下文。

## 为什么不用内置的 `@deepseek-ai/*` 包

profile 里用 `link:` 安装的包位于 profile 目录之外，桌面宿主的 runtime 解析器不会为这个根映射应用内的裸包名（实测 `ERR_MODULE_NOT_FOUND`）。因此 `index.js` 只依赖 `node:` 内置模块与 `ctx` 服务：

- `ctx.sessionTitle.register/refresh/get`
- `ctx.llm.prepareCall(...).stream(...)`
- `ctx.sessions`、`ctx.commands`、`ctx.webServer`

模型调用、输入裁剪、超时与流式装配都由本包自己完成，不依赖内置 title provider 的代码。

## 安装（本机已生效的形态）

1. 依赖（`C:\Users\admin\.dsh\profiles\desktop\package.json`）：
   ```json
   "@local/session-title-control": "link:D:/f30082294/dsh_workspace/session-title-control"
   ```
2. 不需要 bundle 列表项；路由行直接写在 profile patch（`cordis.patch.yml`）里：
   ```yaml
   - id: session-title-llm
     disabled: true
   - insert:
       - id: session-title-control
         name: '@local/session-title-control'
         config: { ... }
   ```
3. 浏览器半由 `@deepseek-ai/dsh-client-modules` 扫描该行的 `package.json.dsh.client` 自动加载，不需要构建步骤。

**注意**：profile patch 里的行导入失败会让桌面版在启动时判定 profile 损坏，从而把 `cordis.patch.yml` / `package.json` 备份为 `*.bak-<时间戳>` 并恢复默认 bundle 列表（本机发生过一次，原因是包里残留了 `@deepseek-ai/*` 裸导入）。改这个包后先确认 `node --check index.js` 通过，再用热重载观察路由是否 200，最后才重启。

## 配置（profile patch 里）

| 键 | 现值 | 说明 |
| --- | --- | --- |
| `targetWords` / `targetCjkCharacters` | 5 / 10 | 标题长度目标（语言自适应） |
| `maxInputBytes` | 16384 | 单次请求输入上限；超长会话自动裁剪（首条 + 最近若干条） |
| `maxOutputTokens` | 4096 | 输出上限（不是目标长度；推理 token 计入） |
| `timeoutMs` | 30000 | **单次尝试**的超时 |
| `maxAttempts` | 5 | 总尝试次数（1–10） |
| `retryBaseDelayMs` / `retryMaxDelayMs` | 500 / 8000 | 退避区间（指数增长，±20% 抖动） |
| `provider` / `model` | 省略 | 可选固定路由；两者必须成对出现，否则启动即报错 |

最坏耗时 ≈ `maxAttempts × timeoutMs + 退避总和`，默认约 2.5 分钟；自动标题在后台跑，不阻塞主回答。

## 重试策略

- 可重试：路由/网络/限流/超时、`finish.kind === 'error'`、输出为空、输出含工具调用或触到 `max-tokens`。
- 不重试（立刻失败）：输入超 `maxInputBytes`、没有可用路由、`provider`/`model` 未成对、配置键未知。
- 每次失败写一条 `logger.warn`（`title attempt n/5 failed …`），每次尝试都会在会话日志里留一条 `session/title-llm-request`，便于核对次数。
- `request.signal` 被取消（用户停止、会话关闭）时立即结束循环。

## 手动重排

- `POST /plugin/session-title-control/retitle`，body `{ "sessionId": "…" }`，同步等待结果并返回 `{ ok, sessionId, title }`；失败返回 400 + `error`。
- `GET /plugin/session-title-control/retitle` 列出**当前打开**的会话及其 provider 标题（诊断用；标题来自确定性回退时这里显示 `null`）。
- 只对 live（已打开）会话有效：`refresh()` 需要会话在内存中。未打开时返回 `session is not open; open it in the app before regenerating the title`。
- 旧会话没有记录过 `request/header` 路由时，必须配置 `provider`/`model` 才能重排。

## 回滚

删除 profile patch 末尾的 `session-title-llm` 禁用项与 `insert` 行，重启即可回到内置行为；随后可把 `package.json` 里的 `link:` 依赖一并删掉。
